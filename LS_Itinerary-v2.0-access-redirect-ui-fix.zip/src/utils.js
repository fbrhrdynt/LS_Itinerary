import crypto from 'node:crypto';

export function inviteCode() {
  return crypto.randomBytes(18).toString('base64url');
}

export function toNumber(value, fallback = 0) {
  const n = Number(value);
  return Number.isFinite(n) ? n : fallback;
}

export function money(value, currency = 'IDR') {
  return new Intl.NumberFormat('id-ID', {
    style: 'currency',
    currency,
    maximumFractionDigits: currency === 'IDR' ? 0 : 2,
  }).format(Number(value || 0));
}

export function dateLabel(value) {
  if (!value) return '-';
  const d = new Date(`${String(value).slice(0, 10)}T00:00:00`);
  return new Intl.DateTimeFormat('id-ID', { day: '2-digit', month: 'short', year: 'numeric' }).format(d);
}

export function shortDate(value) {
  if (!value) return '-';
  const d = new Date(`${String(value).slice(0, 10)}T00:00:00`);
  return new Intl.DateTimeFormat('id-ID', { weekday: 'short', day: '2-digit', month: 'short' }).format(d);
}

export function inputDate(value) {
  if (!value) return '';
  return String(value).slice(0, 10);
}

export function flash(req, type, message) {
  req.session.flash = { type, message };
}

export function safeReturnTo(path, fallback = '/dashboard') {
  if (typeof path !== 'string' || !path.startsWith('/') || path.startsWith('//')) return fallback;

  let parsed;
  try {
    parsed = new URL(path, 'http://local');
  } catch {
    return fallback;
  }

  const allowedPrefixes = ['/dashboard', '/admin', '/trips', '/join'];
  const allowed = allowedPrefixes.some(prefix => parsed.pathname === prefix || parsed.pathname.startsWith(`${prefix}/`));
  if (!allowed) return fallback;

  return `${parsed.pathname}${parsed.search}${parsed.hash}`;
}
